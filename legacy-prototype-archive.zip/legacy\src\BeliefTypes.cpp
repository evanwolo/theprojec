#include "BeliefTypes.h"
// Intentionally empty: header-only types for now
